﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Dominio
{
    internal class Usuario
    {
        public string Nombre { get; set; }
        public string User { set; get; }
        public string Contraseña { set; get; }
        public string Correo { set; get; }
        public DateTime acceso { set; get; }

        public Usuario(string nombre, string user, string contraseña, string correo)
        {
            Nombre = nombre;
            User = user;
            Contraseña = contraseña;
            Correo = correo;
        }
    }
}

