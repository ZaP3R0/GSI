﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Dominio
{
    internal class Usuario
    {
        public string User { set; get; }
        public string Password { set; get; }
        public DateTime acceso { set; get; }
        public Usuario(String user, string password)
        {
            User = user;
            Password = password;

        }

    }
}

