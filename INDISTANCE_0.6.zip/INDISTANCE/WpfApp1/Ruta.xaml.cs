﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Dominio;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para Ruta.xaml
    /// </summary>
    public partial class Ruta : UserControl
    {
        public List<Locate> Locations = new List<Locate>();
        public List<Locate> locates = new List<Locate>();
        private Int32 tiempoEnSegundos = 0;
        public Ruta()
        {
            InitializeComponent();
        }

        private void tbx_Origen_KeyUp(object sender, KeyEventArgs e)
        {
            control_tbx(tbx_Origen,lst_Origen);
        }

        private void tbx_destino_KeyUp(object sender, KeyEventArgs e)
        {
            control_tbx(tbx_destino,lst_Destino);
        }

        private void control_tbx(TextBox t,ListBox lb)
        {
            if(t.Text == String.Empty)
            {
                lb.ItemsSource = null;
                return;
            }
            var resultado = HelperGen.BuscadorPunto(t.Text);

            if(resultado == null)
            {
                return;
            }

            var localizaciones = new List<Locate>();

            foreach(var item in resultado.items)
            {
                localizaciones.Add(new Locate()
                {
                    title = item.title,
                    lat = item.position.lat,
                    lng = item.position.lng
                });
            }


            lb.ItemsSource = localizaciones;


            if (lb.Name.Equals("lst_Destino"))
            {
                locates = localizaciones;
            }
            else
            {
                Locations = localizaciones; 
            }
        }
        private void calcularDistancia(String transporte)
        {

            double lat1 = Locations[lst_Origen.SelectedIndex].lat;
            double lng1 = Locations[lst_Origen.SelectedIndex].lng;
            double lat2 = locates[lst_Destino.SelectedIndex].lat;
            double lng2 = locates[lst_Destino.SelectedIndex].lng;
            var result = HelperGen.GenerarRuta(lat1, lng1, lat2, lng2, transporte);

            Indicaciones.Origen = Locations[lst_Origen.SelectedIndex];
            Indicaciones.Destino = locates[lst_Destino.SelectedIndex];
            Indicaciones.Transporte = transporte;
            Mapa.Origen = Locations[lst_Origen.SelectedIndex];
            Mapa.Destino = locates[lst_Destino.SelectedIndex];


            if (result == null)
            {
                return;
            }


            var listaRoutes = new List<Routes>();
            List<Instruccion> listainstrucion = new List<Instruccion>();
            foreach (var item in result.routes)
            {
                foreach (var item2 in item.sections)
                {
                    foreach (var item3 in item2.actions)
                    {

                        listainstrucion.Add(new Instruccion()
                        {
                            trayecto = item3.instruction
                        });
                    }
                    listaRoutes.Add(new Routes()
                    {
                        distancia = item2.summary.length,
                        tiempo = item2.summary.duration
                    });


                    //lst_DatosRuta.ItemsSource = listainstrucion;

                    tiempoEnSegundos = item2.summary.duration;
                    Int32 horas = (tiempoEnSegundos / 3600);
                    Int32 minutos = ((tiempoEnSegundos - horas * 3600) / 60);
                    Int32 segundos = tiempoEnSegundos - (horas * 3600 + minutos * 60);
                    tbx_Duracion.Text = horas.ToString() + " hora(s) : " + minutos.ToString()
                        + " minuto(s) : " + segundos.ToString() + " segundo(s)";
                    tbx_Distancia.Text = (item2.summary.length / 1000).ToString() + " kilómetro(s)"; 
                }
            }
        }

        private void checkRoute()
        {
            String transport = checkTransport();
            if (lst_Destino.SelectedValue != null && lst_Destino.SelectedValue != null && cbTransporte.SelectedIndex > 0)

            {
                calcularDistancia(transport);
            }
        }

         private string checkTransport()
        {
            if (cbTransporte.SelectedIndex == 1)
            {
                return "pedestrian";
            }
            else if (cbTransporte.SelectedIndex == 2)
            {
                return "car";
            }
            if (cbTransporte.SelectedIndex == 3)
            {
                return "truck";
            }
            return "";
        }

        private void btnCalcularRuta_Click(object sender, RoutedEventArgs e)
        {
            checkRoute();
        }

    }
}
