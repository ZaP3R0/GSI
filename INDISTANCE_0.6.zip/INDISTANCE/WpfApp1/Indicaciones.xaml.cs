﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Dominio;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para Indicaciones.xaml
    /// </summary>
    public partial class Indicaciones : UserControl
    {
        public static Locate Origen = new Locate();
        public static Locate Destino = new Locate();
        public static string Transporte = "";
        public Indicaciones()
        {
            InitializeComponent();
            tbx_Origen.Text = Origen.title;
            tbx_destino.Text = Destino.title;
            calcularInstrucciones(Origen, Destino);
        }

        private void calcularInstrucciones(Locate origen, Locate destino)
        {
            double lat1 = origen.lat;
            double lng1 = origen.lng;
            double lat2 = destino.lat;
            double lng2 = destino.lng;
            var result = HelperGen.GenerarRuta(lat1, lng1, lat2, lng2, Transporte);

            var listaRoutes = new List<Routes>();
            List<Instruccion> listainstrucion = new List<Instruccion>();
            foreach (var item in result.routes)
            {
                foreach (var item2 in item.sections)
                {
                    foreach (var item3 in item2.actions)
                    {

                        listainstrucion.Add(new Instruccion()
                        {
                            trayecto = item3.instruction
                        });
                    }
                    listaRoutes.Add(new Routes()
                    {
                        distancia = item2.summary.length,
                        tiempo = item2.summary.duration
                    });

                    lst_Indicaciones.ItemsSource = listainstrucion;
                }
            }
        }
    }
}

