﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Dominio;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para Mapa.xaml
    /// </summary>
    public partial class Mapa : UserControl
    {
        public static Locate Origen = new Locate();
        public static Locate Destino = new Locate();
        public Mapa()
        {
            InitializeComponent();
            tbx_Origen.Text = Origen.title;
            tbx_Destino.Text = destino.title;
            ObtenerImagen(Origen,Destino);
        }

        private void ObtenerImagen(Locate origen, Locate destino)
        {
            HelperGen.ObtenerImagen(Origen.lat, Origen.lng, Destino.lat, Destino.lng);
            imgMapa.Source = (ImageSource)new ImageSourceConverter().ConvertFromString("dest.jpg");

        }
    }
}
