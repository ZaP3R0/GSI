﻿using Newtonsoft.Json;

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static WpfApp1.Dominio.GeocodeHWGO;
using RestSharp;
using static WpfApp1.Dominio.RouteSearchHWGO;

namespace WpfApp1.Dominio
{
    public static class HelperGen
    {
        
        public static string tokenHWGO = "lCDUb5Ol6Xos1uRifLp-DFTlgbuXjyMDn73PSETQXhc";

        public static RootGeo BuscadorPunto(String lugar)
        {
            var cliente = new RestClient("https://geocode.search.hereapi.com/v1/geocode");
            var peticion = new RestRequest($"?q={lugar}&apikey={tokenHWGO}", Method.GET);
            var respuesta = cliente.Execute(peticion);

            if (respuesta.IsSuccessful)
            {
                RootGeo resultado = JsonConvert.DeserializeObject<RootGeo>(respuesta.Content);
                return resultado;

            }else return null;
        }

        public static RootROUTE GenerarRuta(double lat1, double long1, double lat2, double long2, string transporte)
        {
            System.Globalization.CultureInfo ci = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            ci.NumberFormat.NumberDecimalSeparator = ".";
            System.Threading.Thread.CurrentThread.CurrentCulture = ci;

            var cliente = new RestClient("https://router.hereapi.com/v8/routes");
            var peticion = new RestRequest($"?transportMode={transporte}&lang=es&origin={lat1},{long1}&destination={lat2},{long2}&return=polyline,actions,instructions,summary&apikey={tokenHWGO}", Method.GET);
            var respuesta = cliente.Execute(peticion);

            if (respuesta.IsSuccessful)
            {
                RootROUTE resultado = JsonConvert.DeserializeObject<RootROUTE>(respuesta.Content);
                return resultado;
            }
            else return null;
        }

        public static RootGeo BuscarCiudad(string place)
        {
            var client = new RestClient("https://geocode.search.hereapi.com/v1/geocode");
            var request = new RestRequest($"?q={place}&apikey={tokenHWGO}", Method.GET);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                RootGeo result = JsonConvert.DeserializeObject<RootGeo>(response.Content);
                return result;
            }
            else
            {
                return null;
            }
        }
    }
}
