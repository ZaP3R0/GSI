﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para Registrarse.xaml
    /// </summary>
    public partial class Registrarse : Window
    {
        MainWindow mw = new MainWindow();
        XmlDocument documento = new XmlDocument();
        public Registrarse()
        {
            InitializeComponent();
        }

        private void btnVolver_Click(object sender, RoutedEventArgs e)
        {
            mw.Show();
            this.Close();
        }

        private XmlNode creacionUsuario()
        {
            Dominio.Usuario nuevo = new Dominio.Usuario(tbxNombre.Text, tbxUsuario.Text, tbxContraseña.Text, tbxCorreo.Text);

            XmlElement nodoUsuario = documento.CreateElement("Usuario");
            XmlAttribute nombre = documento.CreateAttribute("NombreyApellidos");
            nombre.Value = nuevo.Nombre;
            nodoUsuario.Attributes.Append(nombre);

            XmlAttribute user = documento.CreateAttribute("Usuario");
            user.Value = nuevo.User;
            nodoUsuario.Attributes.Append(user);

            XmlAttribute password = documento.CreateAttribute("Contraseña");
            password.Value = nuevo.Contraseña;
            nodoUsuario.Attributes.Append(password);

            XmlAttribute email = documento.CreateAttribute("Correo");
            email.Value = nuevo.Correo;
            nodoUsuario.Attributes.Append(email);   

            return nodoUsuario;
        }

        private void AñadirXML()
        {
            documento.Load("listaUsuarios.xml");
            XmlNode Users = creacionUsuario();
            XmlNode nodoRaiz = documento.DocumentElement;
            nodoRaiz.InsertAfter(Users, nodoRaiz.LastChild);
            documento.Save("listaUsuarios.xml");

        }

        private void btnCrearUser_Click(object sender, RoutedEventArgs e)
        {
            AñadirXML();
        }
    }
}
