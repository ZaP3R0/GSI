﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Dominio
{
    public class Instruccion
    {
        public string trayecto { get; set; }   
    }
}
