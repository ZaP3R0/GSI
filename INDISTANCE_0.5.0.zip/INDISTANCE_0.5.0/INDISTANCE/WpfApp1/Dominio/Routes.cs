﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Dominio
{
    public class Routes
    {
        public double distancia { get; set; }
        public int tiempo { get; set; } 
    }
}
