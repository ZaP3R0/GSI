﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Dominio
{
    public class Locate
    {
        public string title { get; set; }
        public double lat { get; set; }
        public double lng { get; set; }

    }
}
